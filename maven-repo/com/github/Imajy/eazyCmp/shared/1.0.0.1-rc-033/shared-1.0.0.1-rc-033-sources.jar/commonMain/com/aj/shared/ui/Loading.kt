package com.aj.shared.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.aj.shared.EazyCmp


@Composable
fun CustomLoading(
    loading: Placeholder = EazyCmp.defaultApiLoadingPlaceholder,
    dismissOnBackPress: Boolean = false,
    onDismiss: () -> Unit = {}
) {
    Dialog(onDismissRequest = { if (dismissOnBackPress) onDismiss() }) {
        Box(
            modifier = Modifier
                .size(100.dp)
                .background(Color.White, MaterialTheme.shapes.medium),
            contentAlignment = Alignment.Center
        ) {

            CustomImage(
                placeholder = loading,
                model = null
            )
        }
    }
}

@Composable
fun CustomLoading(
    loadingPathOrUrl: String,
    dismissOnBackPress: Boolean = false,
    onDismiss: () -> Unit = {}
) {
    CustomLoading(
        loading = Placeholder.from(loadingPathOrUrl),
        dismissOnBackPress = dismissOnBackPress,
        onDismiss = onDismiss
    )
}

suspend fun loadJson(path: String): String? {

    return CustomImageResourceResolver
        .resolveBytes
        ?.invoke(path)
        ?.decodeToString()

}