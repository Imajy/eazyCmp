package com.aj.shared.db

import kotlin.Long
import kotlin.String

public data class ApiQueueEntity(
  public val id: Long,
  public val endpoint: String,
  public val method: String,
  public val bodyPayload: String?,
  public val headers: String?,
  public val createdAt: Long,
)
