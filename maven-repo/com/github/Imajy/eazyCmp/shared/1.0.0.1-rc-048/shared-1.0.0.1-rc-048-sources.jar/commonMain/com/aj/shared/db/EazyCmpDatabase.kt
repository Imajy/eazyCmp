package com.aj.shared.db

import app.cash.sqldelight.Transacter
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlDriver
import app.cash.sqldelight.db.SqlSchema
import com.aj.shared.db.shared.newInstance
import com.aj.shared.db.shared.schema
import kotlin.Unit

public interface EazyCmpDatabase : Transacter {
  public val databaseQueries: DatabaseQueries

  public companion object {
    public val Schema: SqlSchema<QueryResult.Value<Unit>>
      get() = EazyCmpDatabase::class.schema

    public operator fun invoke(driver: SqlDriver): EazyCmpDatabase =
        EazyCmpDatabase::class.newInstance(driver)
  }
}
