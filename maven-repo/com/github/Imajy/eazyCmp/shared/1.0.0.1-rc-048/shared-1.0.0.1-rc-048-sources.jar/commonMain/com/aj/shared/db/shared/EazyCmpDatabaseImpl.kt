package com.aj.shared.db.shared

import app.cash.sqldelight.TransacterImpl
import app.cash.sqldelight.db.AfterVersion
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlDriver
import app.cash.sqldelight.db.SqlSchema
import com.aj.shared.db.DatabaseQueries
import com.aj.shared.db.EazyCmpDatabase
import kotlin.Long
import kotlin.Unit
import kotlin.reflect.KClass

internal val KClass<EazyCmpDatabase>.schema: SqlSchema<QueryResult.Value<Unit>>
  get() = EazyCmpDatabaseImpl.Schema

internal fun KClass<EazyCmpDatabase>.newInstance(driver: SqlDriver): EazyCmpDatabase =
    EazyCmpDatabaseImpl(driver)

private class EazyCmpDatabaseImpl(
  driver: SqlDriver,
) : TransacterImpl(driver), EazyCmpDatabase {
  override val databaseQueries: DatabaseQueries = DatabaseQueries(driver)

  public object Schema : SqlSchema<QueryResult.Value<Unit>> {
    override val version: Long
      get() = 1

    override fun create(driver: SqlDriver): QueryResult.Value<Unit> {
      driver.execute(null, """
          |CREATE TABLE apiQueueEntity (
          |    id INTEGER PRIMARY KEY AUTOINCREMENT,
          |    endpoint TEXT NOT NULL,
          |    method TEXT NOT NULL,
          |    bodyPayload TEXT,
          |    headers TEXT,
          |    createdAt INTEGER NOT NULL
          |)
          """.trimMargin(), 0)
      driver.execute(null, """
          |CREATE TABLE imageChunkEntity (
          |    id TEXT PRIMARY KEY NOT NULL,
          |    fileId TEXT NOT NULL,
          |    chunkIndex INTEGER NOT NULL,
          |    totalChunks INTEGER NOT NULL,
          |    chunkData BLOB NOT NULL,
          |    status TEXT NOT NULL,
          |    uploadUrl TEXT NOT NULL
          |)
          """.trimMargin(), 0)
      return QueryResult.Unit
    }

    override fun migrate(
      driver: SqlDriver,
      oldVersion: Long,
      newVersion: Long,
      vararg callbacks: AfterVersion,
    ): QueryResult.Value<Unit> = QueryResult.Unit
  }
}
